//                                                Universidad Estatal a Distancia

//                                            Escuela de Ciencias Exactas y Naturales

//                                               Cátedra de Ingeniería de Software

//                                                        Proyecto Evaluativo

//                                                      Estructuras de Datos

//                                                         Código: 000824

//                                                 Centro Universitario: San José

//                                                  Andrés Villafuerte González

//                                                      Cédula:1-1835-0456

//                                                           Grupo:01

//                                                      Fecha: 20/07/2025
//-------------------------------------------------------------------------------------------------------------------------------------------
package MainFrame;


// File: MainFrame.java
import Modelo.ListaSolicitudes;
import Modelo.Solicitud;
import javax.swing.*;
import java.awt.*;
import ui.PanelListado;
import ui.PanelRegistro;

/**
 * JFrame principal que usa CardLayout para alternar
 * entre registro y listado.
 */
public class MainFrame extends JFrame {
    private final ListaSolicitudes lista;
    private final CardLayout cardLayout;
    private final JPanel contentPane;
    private final PanelRegistro panelRegistro;
    private final PanelListado panelListado;

    public MainFrame() {
        super("Gestión de Solicitudes de Cine");

        lista       = new ListaSolicitudes();       // Modelo en memoria
        cardLayout  = new CardLayout();             // Para cambiar de vista
        contentPane = new JPanel(cardLayout);       // Contenedor principal

        // Creamos los paneles, inyectando callbacks
        panelRegistro = new PanelRegistro(this::registrarSolicitud);
        panelListado  = new PanelListado(lista, this::mostrarRegistro);

        // Registramos las tarjetas
        contentPane.add(panelRegistro, "REGISTRO");
        contentPane.add(panelListado,  "LISTADO");

        // Configuración de ventana
        setContentPane(contentPane);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(700, 450);
        setLocationRelativeTo(null);

        // Mostramos primero el registro
        mostrarRegistro();
    }

    /** Muestra el formulario de registro */
    private void mostrarRegistro() {
        cardLayout.show(contentPane, "REGISTRO");
    }

    /** Muestra el listado y refresca la tabla */
    private void mostrarListado() {
        panelListado.refreshTable();
        cardLayout.show(contentPane, "LISTADO");
    }

    /**
     * Callback al pulsar "Registrar": crea la solicitud,
     * la agrega a la lista y va al listado.
     */
    private void registrarSolicitud(String nombre) {
        lista.agregar(new Solicitud(nombre));
        mostrarListado();
    }

    /** Main: arranca la aplicación en el hilo de Swing
     * @param args */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainFrame().setVisible(true));
    }
}

/**
 Fuentes consultadas:

Oracle. (n.d.). Java Platform, Standard Edition 8 API Specification. Recuperado el 20 de julio de 2025, de https://docs.oracle.com/javase/8/docs/api/

Oracle. (n.d.). Creating a GUI With Swing. Recuperado el 20 de julio de 2025, de https://docs.oracle.com/javase/tutorial/uiswing/

Oracle. (n.d.). How to Use Tables. Recuperado el 20 de julio de 2025, de https://docs.oracle.com/javase/tutorial/uiswing/components/table.html

Oracle. (n.d.). How to Use CardLayout. Recuperado el 20 de julio de 2025, de https://docs.oracle.com/javase/tutorial/uiswing/layout/card.html

Oracle. (n.d.). Model–View–Controller (MVC) Architecture. Recuperado el 20 de julio de 2025, de https://www.oracle.com/technetwork/java/mvc-140467.html

GeeksforGeeks. (n.d.). Linked List in Java. Recuperado el 20 de julio de 2025, de https://www.geeksforgeeks.org/linked-list-in-java/

Oracle. (n.d.). Class BufferedImage. Recuperado el 20 de julio de 2025, de https://docs.oracle.com/javase/8/docs/api/java/awt/image/BufferedImage.html

Stack Overflow. (n.d.). Stack Overflow. Recuperado el 20 de julio de 2025, de https://stackoverflow.com/

 */