package ui;

import Modelo.Solicitud;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.function.IntConsumer;

/**
 * Panel que representa visualmente una sola solicitud:
 * muestra sus datos, un icono según la edad y un botón "Pagar".
 */
public class CardSolicitud extends JPanel {
    /**
     * Constructor: crea la tarjeta de una solicitud.
     *
     * @param s       Objeto Solicitud cuyos datos se mostrarán.
     * @param onPagar Callback que recibirá el ID cuando se pulse "Pagar".
     */
    public CardSolicitud(Solicitud s, IntConsumer onPagar) {
        // 1) Borde compuesto: margen interior + línea gris
        setBorder(new CompoundBorder(
            new EmptyBorder(5, 5, 5, 5),
            BorderFactory.createLineBorder(Color.GRAY)
        ));

        // 2) Layout: icono | datos | botón
        setLayout(new BorderLayout(5, 5));

        // 3) Ícono a la izquierda, color según rango de edad
        JLabel lblIcon = new JLabel(getIconForAge(s.getEdad()));
        add(lblIcon, BorderLayout.WEST);

        // 4) Panel central con los atributos de la solicitud
        JPanel datos = new JPanel(new GridLayout(0, 1));
        datos.add(new JLabel("ID: "     + s.getId()));      // Muestra el ID
        datos.add(new JLabel("Nombre: " + s.getNombre()));  // Muestra el nombre
        datos.add(new JLabel("Edad: "   + s.getEdad()));    // Muestra la edad
        datos.add(new JLabel("Precio: ¢" + s.getPrecio()));  // Muestra el precio
        add(datos, BorderLayout.CENTER);

        // 5) Botón "Pagar" a la derecha
        JButton btn = new JButton("Pagar");
        btn.addActionListener(e -> onPagar.accept(s.getId()));  // Llama al callback con el ID
        btn.setEnabled(!s.isPagado());                         // Deshabilita si ya está pagado
        add(btn, BorderLayout.EAST);

        // 6) Fondo diferente si la solicitud ya está pagada
        setBackground(s.isPagado() ? Color.LIGHT_GRAY : Color.WHITE);
    }

    /**
     * Crea un icono circular de 32x32 px:
     * - Verde si edad ≤ 20
     * - Azul si 21 ≤ edad ≤ 64
     * - Naranja si edad ≥ 65
     *
     * @param edad Edad de la solicitud, para colorear el icono.
     * @return Icono coloreado.
     */
    private Icon getIconForAge(int edad) {
        Color color;
        if (edad <= 20)       color = Color.GREEN;
        else if (edad <= 64)  color = Color.BLUE;
        else                   color = Color.ORANGE;

        // Dibujar un círculo en una imagen BufferedImage
        BufferedImage img = new BufferedImage(32, 32, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = img.createGraphics();
        g.setColor(color);
        g.fillOval(0, 0, 32, 32);
        g.dispose();

        return new ImageIcon(img);
    }
}