package ui;

import javax.swing.*;
import java.awt.*;
import java.util.function.Consumer;

/**
 * Panel para el formulario de registro de nombre.
 * Recibe un Consumer<String> que es la acción al pulsar "Registrar".
 */
public class PanelRegistro extends JPanel {
    private final JTextField txtNombre;

    public PanelRegistro(Consumer<String> onRegistrar) {
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        // Etiqueta
        gbc.insets = new Insets(5,5,5,5);
        gbc.gridx = 0; gbc.gridy = 0;
        add(new JLabel("Nombre del solicitante:"), gbc);

        // Campo de texto
        txtNombre = new JTextField(20);
        gbc.gridx = 1;
        add(txtNombre, gbc);

        // Botón Registrar
        JButton btnRegistrar = new JButton("Registrar");
        gbc.gridx = 0; gbc.gridy = 1; gbc.gridwidth = 2;
        add(btnRegistrar, gbc);

        // Al hacer clic, pasa el texto al callback y limpia el campo
        btnRegistrar.addActionListener(e -> {
            String nombre = txtNombre.getText().trim();
            if (!nombre.isEmpty()) {
                onRegistrar.accept(nombre);
                txtNombre.setText("");
            }
        });
    }
}
