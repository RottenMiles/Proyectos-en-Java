package ui;

import Modelo.ListaSolicitudes;
import Modelo.SolicitudesTableModel;

import javax.swing.*;
import java.awt.*;

/**
 * Panel que muestra un JTable con las solicitudes y
 * botones para "Pagar selección" y "Registrar nueva".
 */
public class PanelListado extends JPanel {
    private final JTable table;
    private final SolicitudesTableModel tableModel;

    public PanelListado(ListaSolicitudes lista, Runnable onVolver) {
        setLayout(new BorderLayout(10, 10));

        // 1) Creamos modelo y JTable
        tableModel = new SolicitudesTableModel(lista);
        table = new JTable(tableModel);
        add(new JScrollPane(table), BorderLayout.CENTER);

        // 2) Barra de botones
        JPanel botones = new JPanel();
        JButton btnPagar  = new JButton("Pagar selección");
        JButton btnVolver = new JButton("Registrar nueva");
        botones.add(btnPagar);
        botones.add(btnVolver);
        add(botones, BorderLayout.SOUTH);

        // 3) Acción de pagar: elimina por ID y refresca
        btnPagar.addActionListener(e -> {
            int viewRow = table.getSelectedRow();
            if (viewRow >= 0) {
                int modelRow = table.convertRowIndexToModel(viewRow);
                int id = (int) tableModel.getValueAt(modelRow, 0);
                lista.eliminar(id);
                refreshTable();
            }
        });

        // 4) Volver a la pantalla de registro
        btnVolver.addActionListener(e -> onVolver.run());
    }

    /** Refresca los datos de la tabla tras un cambio en el modelo */
    public void refreshTable() {
        tableModel.refresh();
        if (table.getRowCount() > 0) {
            table.setRowSelectionInterval(0, 0);
        }
    }
}