package Modelo;

import java.util.ArrayList;
import java.util.List;

/**
 * Implementa una lista enlazada simple de Solicitudes.
 * Ofrece operaciones de agregar, eliminar por ID y listar.
 */
public class ListaSolicitudes {
    private NodoSolicitud cabeza;  // Inicio de la lista

    /** Agrega una solicitud al final de la lista
     * @param s */
    public void agregar(Solicitud s) {
        NodoSolicitud nuevo = new NodoSolicitud(s);
        if (cabeza == null) {
            // Si está vacía, el nuevo es la cabeza
            cabeza = nuevo;
        } else {
            // Si no, recorremos hasta el final y enlazamos
            NodoSolicitud aux = cabeza;
            while (aux.getSiguiente() != null) {
                aux = aux.getSiguiente();
            }
            aux.setSiguiente(nuevo);
        }
    }

    /**
     * Elimina la solicitud cuyo ID coincide.
     * @param id
     * @return true si se eliminó, false si no se encontró.
     */
    public boolean eliminar(int id) {
        if (cabeza == null) return false;

        // Caso especial: la cabeza es el ID buscado
        if (cabeza.getDato().getId() == id) {
            cabeza = cabeza.getSiguiente();
            return true;
        }

        // Recorremos manteniendo nodo anterior
        NodoSolicitud prev = cabeza;
        NodoSolicitud actual = cabeza.getSiguiente();
        while (actual != null) {
            if (actual.getDato().getId() == id) {
                // Saltamos el nodo encontrado
                prev.setSiguiente(actual.getSiguiente());
                return true;
            }
            prev = actual;
            actual = actual.getSiguiente();
        }
        return false;
    }

    /**
     * Recorre la lista de principio a fin y retorna
     * un ArrayList con todas las Solicitudes.
     * @return 
     */
    public List<Solicitud> listar() {
        List<Solicitud> lista = new ArrayList<>();
        NodoSolicitud aux = cabeza;
        while (aux != null) {
            lista.add(aux.getDato());
            aux = aux.getSiguiente();
        }
        return lista;
    }
}
