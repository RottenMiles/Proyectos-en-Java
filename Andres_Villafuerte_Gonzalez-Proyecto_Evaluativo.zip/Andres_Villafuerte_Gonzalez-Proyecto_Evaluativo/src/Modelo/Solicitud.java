package Modelo;


import java.util.Random;

public class Solicitud {
    // Contador estático para asignar IDs únicos
    private static int contadorID = 1;

    // Atributos de la solicitud
    private final int id;
    private final String nombre;
    private final int edad;
    private final int precio;
    private boolean pagado;

    /**
     * Constructor: recibe el nombre, genera ID, calcula edad y precio, inicia pagado en false.
     * @param nombre
     */
    public Solicitud(String nombre) {
        this.id = contadorID++;                    // Asigna ID y aumenta el contador
        this.nombre = nombre;                      // Nombre proporcionado por el usuario
        this.edad = generateEdad();                // Edad aleatoria entre 12 y 100
        this.precio = calcularPrecio(edad);        // Precio según tramo de edad
        this.pagado = false;                       // Nunca está pagado al crearse
    }

    /** Genera un valor aleatorio de edad entre 12 y 100 */
    private int generateEdad() {
        return new Random().nextInt(89) + 12;
    }

    /** Calcula el precio en colones según la edad */
    private int calcularPrecio(int edad) {
        if (edad < 18)       return 2500;
        else if (edad < 60)  return 4500;
        else                 return 3000;
    }

    // Getters y setter para el campo pagado
    public int getId()            { return id;      }
    public String getNombre()     { return nombre;  }
    public int getEdad()          { return edad;    }
    public int getPrecio()        { return precio;  }
    public boolean isPagado()     { return pagado;  }
    public void setPagado(boolean p) { this.pagado = p; }
}