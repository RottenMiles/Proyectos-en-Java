package Modelo;

/**
 * Nodo de la lista enlazada simple que almacena una Solicitud
 * y referencia al siguiente nodo.
 */
public class NodoSolicitud {
    private final Solicitud dato;         // La solicitud contenida
    private NodoSolicitud siguiente; // Enlace al siguiente nodo

    public NodoSolicitud(Solicitud dato) {
        this.dato = dato;
    }

    // Getters y setters
    public Solicitud getDato() {
        return dato;
    }

    public NodoSolicitud getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(NodoSolicitud siguiente) {
        this.siguiente = siguiente;
    }
}