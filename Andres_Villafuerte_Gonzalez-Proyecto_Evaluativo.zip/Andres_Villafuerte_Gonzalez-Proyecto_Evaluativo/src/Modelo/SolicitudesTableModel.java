package Modelo;

import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 * TableModel personalizado para mostrar las solicitudes
 * llamando a lista.listar() y exponiendo 5 columnas.
 */
public class SolicitudesTableModel extends AbstractTableModel {
    private final ListaSolicitudes lista;
    private final String[] columnas = {"ID", "Nombre", "Edad", "Precio", "Pagado"};

    public SolicitudesTableModel(ListaSolicitudes lista) {
        this.lista = lista;
    }

    @Override
    public int getRowCount() {
        return lista.listar().size();  // Número de filas = tamaño de la lista
    }

    @Override
    public int getColumnCount() {
        return columnas.length;         // Cinco columnas
    }

    @Override
    public String getColumnName(int col) {
        return columnas[col];           // Nombre de cada columna
    }

    @Override
    public Object getValueAt(int row, int col) {
        List<Solicitud> datos = lista.listar();
        Solicitud s = datos.get(row);
        return switch (col) {
            case 0 -> s.getId();
            case 1 -> s.getNombre();
            case 2 -> s.getEdad();
            case 3 -> s.getPrecio();
            case 4 -> s.isPagado();
            default -> "";
        };
    }

    /** Notifica a la tabla que los datos cambiaron */
    public void refresh() {
        fireTableDataChanged();
    }
}