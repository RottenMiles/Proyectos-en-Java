/*
 * VentanaListadoCelebraciones.java
 * Pantalla GUI para listar todas las celebraciones registradas.
 */
package ui;

import modelo.Celebracion;
import modelo.GestorCelebraciones;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.Iterator;

public class VentanaListadoCelebraciones extends JFrame {
    private JTable tabla;                     // Tabla para mostrar datos
    private DefaultTableModel modeloTabla;    // Modelo de tabla
    private final GestorCelebraciones gestor; // Gestor compartido

     /**
     * Constructor: configura la ventana y carga datos.
     */
     public VentanaListadoCelebraciones(GestorCelebraciones gestor) {
        this.gestor = gestor;
        setTitle("Listado de Celebraciones");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(600, 400);
        setLocationRelativeTo(null);
        initComponents();
        cargarDatos();
    }

    private void initComponents() {
        // Columnas de la tabla: ID, Fecha, Descripción, País
        String[] columnas = {"ID", "Fecha", "Descripción", "País"};
        modeloTabla = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // tabla de solo lectura
            }
        };

        tabla = new JTable(modeloTabla);
        JScrollPane scroll = new JScrollPane(tabla);

        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(scroll, BorderLayout.CENTER);

        // Botón Refrescar
        JButton btnRefrescar = new JButton("Refrescar");
        btnRefrescar.addActionListener(e -> cargarDatos());
        JPanel panelBotones = new JPanel();
        panelBotones.add(btnRefrescar);
        getContentPane().add(panelBotones, BorderLayout.SOUTH);
    }

     /**
     * Llena la tabla usando el iterador de GestorCelebraciones.
     */
    private void cargarDatos() {
        // Limpiar la tabla
        modeloTabla.setRowCount(0);

        // Obtener iterador y llenar filas
        Iterator<Celebracion> iter = gestor.obtenerIterador();
        while (iter.hasNext()) {
            Celebracion c = iter.next();
            Object[] fila = {
                    c.getId(),
                    c.getFecha(),
                    c.getDescripcion(),
                    c.getPais()
            };
            modeloTabla.addRow(fila);
        }
    }

    // Para probar esta ventana de forma independiente
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            GestorCelebraciones gestor = new GestorCelebraciones();
            // Agregar algunos datos de prueba
            gestor.agregar(new Celebracion(gestor.obtenerSiguienteId(), java.time.LocalDate.now(), "Demo", "Costa Rica"));
            new VentanaListadoCelebraciones(gestor).setVisible(true);
        });
    }
}
