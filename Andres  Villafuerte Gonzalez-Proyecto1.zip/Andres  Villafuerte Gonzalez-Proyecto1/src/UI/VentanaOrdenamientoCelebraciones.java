/*
 * VentanaOrdenamientoCelebraciones.java
 * Aplica ordenamiento por inserción y muestra las celebraciones ordenadas.
 */
package ui;

import modelo.Celebracion;
import modelo.GestorCelebraciones;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class VentanaOrdenamientoCelebraciones extends JFrame {
    private JTable tabla;
    private DefaultTableModel modelo;
    private final GestorCelebraciones gestor;

    public VentanaOrdenamientoCelebraciones(GestorCelebraciones gestor) {
        this.gestor = gestor;
        setTitle("Ordenamiento por Inserción");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(600, 400);
        setLocationRelativeTo(null);
        initComponents();
        ordenarYMostrar();
    }

    private void initComponents() {
        String[] cols = {"ID", "País", "Fecha", "Descripción"};
        modelo = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        tabla = new JTable(modelo);
        add(new JScrollPane(tabla), BorderLayout.CENTER);
    }

    private void ordenarYMostrar() {
        List<Celebracion> lista = new ArrayList<>(gestor.obtenerTodas());
        // Insertion sort por país y luego fecha
        for (int i = 1; i < lista.size(); i++) {
            Celebracion key = lista.get(i);
            int j = i - 1;
            while (j >= 0 && comparar(lista.get(j), key) > 0) {
                lista.set(j+1, lista.get(j));
                j--;
            }
            lista.set(j+1, key);
        }
        // Mostrar en tabla
        modelo.setRowCount(0);
        for (Celebracion c : lista) {
            modelo.addRow(new Object[]{c.getId(), c.getPais(), c.getFecha(), c.getDescripcion()});
        }
    }

    /**
     * Compara dos celebraciones: por país, luego por fecha.
     */
    private int comparar(Celebracion a, Celebracion b) {
        int cmp = a.getPais().compareToIgnoreCase(b.getPais());
        if (cmp != 0) return cmp;
        return a.getFecha().compareTo(b.getFecha());
    }
}
