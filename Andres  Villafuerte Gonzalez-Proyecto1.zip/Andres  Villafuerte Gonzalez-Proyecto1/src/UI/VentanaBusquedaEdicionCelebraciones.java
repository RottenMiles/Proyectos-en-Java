// ------------------------------
// ui/VentanaBusquedaEdicionCelebraciones.java
// Búsqueda y edición de celebraciones.
// ------------------------------
package ui;

import modelo.Celebracion;
import modelo.GestorCelebraciones;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Ventana para buscar celebraciones por país y editar registros seleccionados.
 * Los mensajes de estado se muestran en una etiqueta en lugar de cuadros de diálogo.
 */
public class VentanaBusquedaEdicionCelebraciones extends JFrame {
    // Componentes de búsqueda
    private JTextField txtPaisBusqueda;      // Campo para ingresar texto de búsqueda de país
    private JButton btnBuscar;              // Botón para ejecutar búsqueda

    // Tabla de resultados
    private JTable tablaResultados;
    private DefaultTableModel modeloTabla;

    // Componentes de edición
    private JLabel lblId;                   // Muestra el ID del registro seleccionado
    private JSpinner spinnerFecha;          // Selector de fecha para edición
    private JTextField txtDescripcion;      // Campo para editar descripción
    private JTextField txtPais;             // Campo para editar país
    private JButton btnGuardarCambios;      // Botón para guardar cambios

    // Etiqueta de estado
    private JLabel lblEstado;               // Muestra mensajes de validación o éxito

    // Lógica de negocio
    private final GestorCelebraciones gestor;
    private Celebracion seleccionada;

    /**
     * Constructor: recibe el gestor compartido y configura la ventana.
     */
    public VentanaBusquedaEdicionCelebraciones(GestorCelebraciones gestor) {
        this.gestor = gestor;
        setTitle("Búsqueda y Edición de Celebraciones");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(720, 550);
        setLocationRelativeTo(null);
        initComponents();
    }

    /**
     * Inicializa y organiza todos los componentes de la interfaz.
     */
    private void initComponents() {
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));

        // Panel de búsqueda
        JPanel pnlBusqueda = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 5));
        pnlBusqueda.add(new JLabel("País:"));
        txtPaisBusqueda = new JTextField(20);
        pnlBusqueda.add(txtPaisBusqueda);
        btnBuscar = new JButton("Buscar");
        btnBuscar.addActionListener(this::buscar);
        pnlBusqueda.add(btnBuscar);
        mainPanel.add(pnlBusqueda, BorderLayout.NORTH);

        // Tabla de resultados
        String[] columnas = {"ID", "Fecha", "Descripción", "País"};
        modeloTabla = new DefaultTableModel(columnas, 0) {
            @Override public boolean isCellEditable(int row, int col) {
                return false; // Solo lectura
            }
        };
        tablaResultados = new JTable(modeloTabla);
        tablaResultados.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tablaResultados.getSelectionModel().addListSelectionListener(this::filaSeleccionada);
        mainPanel.add(new JScrollPane(tablaResultados), BorderLayout.CENTER);

        // Panel de edición y estado en la parte inferior
        JPanel pnlEdicion = new JPanel(new GridBagLayout());
        pnlEdicion.setBorder(BorderFactory.createTitledBorder("Editar registro seleccionado"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // ID (solo lectura)
        lblId = new JLabel();
        gbc.gridx = 0; gbc.gridy = 0;
        pnlEdicion.add(new JLabel("ID:"), gbc);
        gbc.gridx = 1;
        pnlEdicion.add(lblId, gbc);

        // Fecha
        spinnerFecha = new JSpinner(new SpinnerDateModel());
        spinnerFecha.setEditor(new JSpinner.DateEditor(spinnerFecha, "yyyy-MM-dd"));
        gbc.gridx = 0; gbc.gridy = 1;
        pnlEdicion.add(new JLabel("Fecha:"), gbc);
        gbc.gridx = 1;
        pnlEdicion.add(spinnerFecha, gbc);

        // Descripción
        txtDescripcion = new JTextField();
        gbc.gridx = 0; gbc.gridy = 2;
        pnlEdicion.add(new JLabel("Descripción:"), gbc);
        gbc.gridx = 1;
        pnlEdicion.add(txtDescripcion, gbc);

        // País
        txtPais = new JTextField();
        gbc.gridx = 0; gbc.gridy = 3;
        pnlEdicion.add(new JLabel("País:"), gbc);
        gbc.gridx = 1;
        pnlEdicion.add(txtPais, gbc);

        // Botón Guardar Cambios
        btnGuardarCambios = new JButton("Guardar Cambios");
        btnGuardarCambios.setEnabled(false);
        btnGuardarCambios.addActionListener(this::guardarCambios);
        gbc.gridx = 0; gbc.gridy = 4; gbc.gridwidth = 2;
        pnlEdicion.add(btnGuardarCambios, gbc);

        // Etiqueta de Estado
        lblEstado = new JLabel(" ");
        gbc.gridy = 5;
        pnlEdicion.add(lblEstado, gbc);

        mainPanel.add(pnlEdicion, BorderLayout.SOUTH);
        add(mainPanel);
    }

    /**
     * Busca celebraciones cuyo país contenga el texto ingresado y muestra resultados.
     */
    private void buscar(ActionEvent e) {
        String filtro = txtPaisBusqueda.getText().trim().toLowerCase();
        List<Celebracion> resultados = gestor.obtenerTodas().stream()
            .filter(c -> c.getPais().toLowerCase().contains(filtro))
            .collect(Collectors.toList());

        modeloTabla.setRowCount(0);
        for (Celebracion c : resultados) {
            modeloTabla.addRow(new Object[]{c.getId(), c.getFecha(), c.getDescripcion(), c.getPais()});
        }
        btnGuardarCambios.setEnabled(false);
        lblEstado.setText(" ");
        seleccionada = null;
    }

    /**
     * Carga en el formulario de edición los datos del registro seleccionado.
     */
    private void filaSeleccionada(ListSelectionEvent evt) {
        if (!evt.getValueIsAdjusting() && tablaResultados.getSelectedRow() != -1) {
            int row = tablaResultados.getSelectedRow();
            int id = (int) modeloTabla.getValueAt(row, 0);
            seleccionada = gestor.obtenerTodas().stream()
                .filter(c -> c.getId() == id)
                .findFirst().orElse(null);
            if (seleccionada != null) {
                lblId.setText(String.valueOf(seleccionada.getId()));
                Date fechaDate = Date.from(
                    seleccionada.getFecha().atStartOfDay(ZoneId.systemDefault()).toInstant());
                spinnerFecha.setValue(fechaDate);
                txtDescripcion.setText(seleccionada.getDescripcion());
                txtPais.setText(seleccionada.getPais());
                btnGuardarCambios.setEnabled(true);
                lblEstado.setText(" ");
            }
        }
    }

    /**
     * Guarda los cambios realizados en el objeto seleccionado y refresca la tabla.
     */
    private void guardarCambios(ActionEvent e) {
        if (seleccionada != null) {
            Date fechaDate = (Date) spinnerFecha.getValue();
            LocalDate fecha = fechaDate.toInstant()
                .atZone(ZoneId.systemDefault())
                .toLocalDate();
            seleccionada.setFecha(fecha);
            seleccionada.setDescripcion(txtDescripcion.getText().trim());
            seleccionada.setPais(txtPais.getText().trim());

            lblEstado.setText("Cambios guardados correctamente.");
            buscar(null);
        }
    }

    /**
     * Main de prueba para ejecutar esta ventana de forma aislada.
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() ->
            new VentanaBusquedaEdicionCelebraciones(new GestorCelebraciones()).setVisible(true)
        );
    }
}
