/*
 * VentanaRegistroCelebracion.java
 * Formulario GUI para registrar nuevas celebraciones.
 */
package ui;

import modelo.Celebracion;
import modelo.GestorCelebraciones;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;

/**
 * Ventana para registrar nuevas celebraciones.
 * No usa cuadros de diálogo para operaciones exitosas, sino una JLabel de estado.
 */
public class VentanaRegistroCelebracion extends JFrame {
    private JLabel lblId;               // Muestra el próximo ID disponible
    private JSpinner spinnerFecha;      // Selector de fecha
    private JTextField txtDescripcion;  // Campo de descripción
    private JTextField txtPais;         // Campo de país
    private JButton btnGuardar;         // Botón para guardar
    private JLabel lblEstado;           // Etiqueta para mensajes de validación/estado

    private final GestorCelebraciones gestor;  // Gestor compartido

    public VentanaRegistroCelebracion(GestorCelebraciones gestor) {
        this.gestor = gestor;
        setTitle("Registro de Celebración");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(400, 330);
        setLocationRelativeTo(null);
        initComponents();
    }

    private void initComponents() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5,5,5,5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // ID
        lblId = new JLabel();
        actualizarId();
        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(new JLabel("ID:"), gbc);
        gbc.gridx = 1;
        panel.add(lblId, gbc);

        // Fecha
        spinnerFecha = new JSpinner(new SpinnerDateModel(new Date(), null, null, java.util.Calendar.DAY_OF_MONTH));
        spinnerFecha.setEditor(new JSpinner.DateEditor(spinnerFecha, "yyyy-MM-dd"));
        gbc.gridx = 0; gbc.gridy = 1;
        panel.add(new JLabel("Fecha:"), gbc);
        gbc.gridx = 1;
        panel.add(spinnerFecha, gbc);

        // Descripción
        txtDescripcion = new JTextField();
        gbc.gridx = 0; gbc.gridy = 2;
        panel.add(new JLabel("Descripción:"), gbc);
        gbc.gridx = 1;
        panel.add(txtDescripcion, gbc);

        // País
        txtPais = new JTextField();
        gbc.gridx = 0; gbc.gridy = 3;
        panel.add(new JLabel("País:"), gbc);
        gbc.gridx = 1;
        panel.add(txtPais, gbc);

        // Botón Guardar
        btnGuardar = new JButton("Guardar");
        gbc.gridx = 0; gbc.gridy = 4; gbc.gridwidth = 2;
        panel.add(btnGuardar, gbc);
        btnGuardar.addActionListener(this::guardarCelebracion);

        // Etiqueta de Estado
        lblEstado = new JLabel(" ");
        gbc.gridx = 0; gbc.gridy = 5; gbc.gridwidth = 2;
        panel.add(lblEstado, gbc);

        add(panel);
    }

    private void actualizarId() {
        // Calcula el próximo ID sin modificar la lista original
        lblId.setText(String.valueOf(gestor.obtenerSiguienteId()));
    }

    private void guardarCelebracion(ActionEvent e) {
        Date date = (Date) spinnerFecha.getValue();
        String desc = txtDescripcion.getText().trim();
        String pais = txtPais.getText().trim();

        // Validación de campos
        if (date == null || desc.isEmpty() || pais.isEmpty()) {
            lblEstado.setText("Error: complete todos los campos.");
            return;
        }

        // Conversión a LocalDate
        LocalDate fecha = date.toInstant()
                .atZone(ZoneId.systemDefault())
                .toLocalDate();

        // Crear y agregar la nueva celebración
        Celebracion c = new Celebracion(
                gestor.obtenerSiguienteId(),
                fecha,
                desc,
                pais
        );
        gestor.agregar(c);

        // Actualizar interfaz
        actualizarId();
        spinnerFecha.setValue(new Date());
        txtDescripcion.setText("");
        txtPais.setText("");
        lblEstado.setText("Celebración registrada correctamente.");
    }

    // Para pruebas aisladas
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() ->
            new VentanaRegistroCelebracion(new GestorCelebraciones()).setVisible(true)
        );
    }
}
