/*
 * VentanaPaisesInvertidos.java
 * Muestra los países registrados invertidos usando recursividad.
 */
package ui;

import modelo.Celebracion;
import modelo.GestorCelebraciones;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.stream.Collectors;

public class VentanaPaisesInvertidos extends JFrame {
    private JTable tabla;
    private DefaultTableModel modelo;
    private final GestorCelebraciones gestor;

    public VentanaPaisesInvertidos(GestorCelebraciones gestor) {
        this.gestor = gestor;
        setTitle("Países Invertidos");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(400, 300);
        setLocationRelativeTo(null);
        initComponents();
        cargarPaisesInvertidos();
    }

    private void initComponents() {
        String[] columnas = {"País Original", "País Invertido"};
        modelo = new DefaultTableModel(columnas, 0) {
            @Override public boolean isCellEditable(int row, int col) { return false; }
        };
        tabla = new JTable(modelo);
        add(new JScrollPane(tabla), BorderLayout.CENTER);
    }

    private void cargarPaisesInvertidos() {
        // Obtener países únicos
        List<String> paises = gestor.obtenerTodas().stream()
                .map(Celebracion::getPais)
                .collect(Collectors.toCollection(LinkedHashSet::new))
                .stream().collect(Collectors.toList());

        modelo.setRowCount(0);
        for (String pais : paises) {
            modelo.addRow(new Object[]{pais, invertirRecursivo(pais)});
        }
    }

    /**
     * Función recursiva para invertir una cadena.
     * @param s Cadena original
     * @return Cadena invertida
     */
    private String invertirRecursivo(String s) {
        if (s == null || s.length() <= 1) {
            return s == null ? "" : s;
        }
        return invertirRecursivo(s.substring(1)) + s.charAt(0);
    }
}
