//                                                Universidad Estatal a Distancia

//                                            Escuela de Ciencias Exactas y Naturales

//                                               Cátedra de Ingeniería de Software

//                                                           PROYECTO: #01

//                                                      Estructuras de Datos

//                                                         Código: 000824

//                                                 Centro Universitario: San José

//                                                  Andrés Villafuerte González

//                                                      Cédula:1-1835-0456

//                                                           Grupo:01

//                                                      Fecha: 20/06/2025
//-------------------------------------------------------------------------------------------------------------------------------------------
/*
 * MainApp.java
 * Punto de entrada con un launcher para las distintas ventanas,
 * incluyendo países invertidos y ordenamiento por inserción.
 */
package app;

import modelo.GestorCelebraciones;
import ui.VentanaRegistroCelebracion;
import ui.VentanaListadoCelebraciones;
import ui.VentanaBusquedaEdicionCelebraciones;
import ui.VentanaPaisesInvertidos;
import ui.VentanaOrdenamientoCelebraciones;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class MainApp extends JFrame {
    private final GestorCelebraciones gestor;

    public MainApp() {
        gestor = new GestorCelebraciones();
        setTitle("Gestión de Celebraciones");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 280);
        setLocationRelativeTo(null);
        initUI();
    }

    //Botones del menu GUI
    private void initUI() {
        JPanel panel = new JPanel(new GridLayout(5, 1, 5, 5));

        JButton btnRegistro = new JButton("Nuevo Registro");
        btnRegistro.addActionListener(this::abrirRegistro);
        panel.add(btnRegistro);

        JButton btnListado = new JButton("Ver Listado");
        btnListado.addActionListener(this::abrirListado);
        panel.add(btnListado);

        JButton btnBusqueda = new JButton("Buscar/Editar");
        btnBusqueda.addActionListener(this::abrirBusqueda);
        panel.add(btnBusqueda);

        JButton btnInvertidos = new JButton("Países Invertidos");
        btnInvertidos.addActionListener(this::abrirInvertidos);
        panel.add(btnInvertidos);

        JButton btnOrdenamiento = new JButton("Ordenamiento (Inserción)");
        btnOrdenamiento.addActionListener(this::abrirOrdenamiento);
        panel.add(btnOrdenamiento);

        add(panel);
    }

    //Abre las diversas ventanas 
    private void abrirRegistro(ActionEvent e) {
        new VentanaRegistroCelebracion(gestor).setVisible(true);
    }

    private void abrirListado(ActionEvent e) {
        new VentanaListadoCelebraciones(gestor).setVisible(true);
    }

    private void abrirBusqueda(ActionEvent e) {
        new VentanaBusquedaEdicionCelebraciones(gestor).setVisible(true);
    }

    private void abrirInvertidos(ActionEvent e) {
        new VentanaPaisesInvertidos(gestor).setVisible(true);
    }

    private void abrirOrdenamiento(ActionEvent e) {
        new VentanaOrdenamientoCelebraciones(gestor).setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainApp().setVisible(true));
    }
}
