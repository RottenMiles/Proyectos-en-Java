/// ------------------------------
// modelo/Celebracion.java
// Clase de dominio que representa una celebración única.
// ------------------------------
package modelo;

import java.time.LocalDate;

public class Celebracion {
    private final int id;           // Identificador único e inmóvil de la celebración
    private LocalDate fecha;        // Fecha en que ocurre la celebración
    private String descripcion;     // Breve descripción de la celebración
    private String pais;            // País al que pertenece la celebración

    /**
     * Constructor que inicializa todos los campos.
     * @param id           Identificador único proveniente de GestorCelebraciones
     * @param fecha        Fecha de la celebración
     * @param descripcion  Texto descriptivo de la celebración
     * @param pais         Nombre del país asociado
     */
    public Celebracion(int id, LocalDate fecha, String descripcion, String pais) {
        this.id = id;
        this.fecha = fecha;
        this.descripcion = descripcion;
        this.pais = pais;
    }

    // GETTERS Y SETTERS
    public int getId() { return id; }
    public LocalDate getFecha() { return fecha; }
    public void setFecha(LocalDate fecha) { this.fecha = fecha; }
    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
    public String getPais() { return pais; }
    public void setPais(String pais) { this.pais = pais; }

    @Override
    public String toString() {
        return String.format("Celebración{id=%d, fecha=%s, país=%s, descripción=%s}",
                              id, fecha, pais, descripcion);
    }
}


