// ------------------------------
// modelo/GestorCelebraciones.java
// Clase que gestiona la lista de celebraciones en memoria.
// ------------------------------
package modelo;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class GestorCelebraciones {
    private List<Celebracion> lista;  // Lista interna que almacena Celebracion

    /**
     * Constructor: inicializa la colección vacía.
     */
    public GestorCelebraciones() {
        lista = new ArrayList<>();
    }

    /**
     * Agrega una nueva celebración a la lista.
     * @param c Celebracion a añadir
     */
    public void agregar(Celebracion c) {
        lista.add(c);
    }

    /**
     * Obtiene una copia de todas las celebraciones.
     * @return Nueva lista con todas las Celebracion
     */
    public List<Celebracion> obtenerTodas() {
        return new ArrayList<>(lista);
    }

    /**
     * Proporciona un iterador para recorrer sin exponer la lista.
     * @return Iterator sobre Celebracion
     */
    public Iterator<Celebracion> obtenerIterador() {
        return lista.iterator();
    }

    /**
     * Calcula el siguiente ID disponible (longitud+1).
     * @return ID para la siguiente Celebracion
     */
    public int obtenerSiguienteId() {
        return lista.size() + 1;
    }
}
