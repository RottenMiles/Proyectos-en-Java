FlatLaf Natives using JNA
=========================

This sub-project contains source code that uses
[JNA](https://github.com/java-native-access/jna) to access native operating
system API.

**Note:** Code in this sub-project is **not used** in FlatLaf libraries. It was
used to develop/test usage of some native operating system API in Java (with the
help of JNA) and was then converted to C++.
