Fonts
=====

The sub-projects contains fonts from some font families and bundles them into
easy-to-use and redistributable JARs.

- [Inter](flatlaf-fonts-inter) font
- [JetBrains Mono](flatlaf-fonts-jetbrains-mono) font
- [Roboto](flatlaf-fonts-roboto) font
- [Roboto Mono](flatlaf-fonts-roboto-mono) font
