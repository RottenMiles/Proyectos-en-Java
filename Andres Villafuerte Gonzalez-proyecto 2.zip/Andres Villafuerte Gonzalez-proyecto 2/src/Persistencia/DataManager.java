package Persistencia;

import modelo.Departamento;
import modelo.Articulo;
import estructura.PilaDepartamentos;

import java.io.*;
import java.nio.file.*;
import java.util.List;

/**
 * Responsable de guardar y cargar la pila de Departamentos y sus Artículos.
 */
public class DataManager {

    private static final String DIR = "data";               // Carpeta base
    private static final String DEPTS_FILE = "departamentos.txt";

    /**
     * Guarda todos los departamentos y sus colas en archivos.
     */
    public static void saveAll(PilaDepartamentos pila) throws IOException {
        // Asegurarse de que exista la carpeta
        Files.createDirectories(Paths.get(DIR));

        // 1) Guardar departamentos
        try (BufferedWriter writer = Files.newBufferedWriter(
                Paths.get(DIR, DEPTS_FILE))) {
            for (Departamento d : pila.toArray()) {
                writer.write(d.getId() + ";" + d.getNombre());
                writer.newLine();
            }
        }

        // 2) Guardar artículos por departamento
        for (Departamento d : pila.toArray()) {
            String fileName = "articulos_" + d.getId() + ".txt";
            try (BufferedWriter w2 = Files.newBufferedWriter(
                    Paths.get(DIR, fileName))) {
                for (Articulo a : d.getArticulosEnCola()) {
                    w2.write(a.getId() + ";" + a.getNombre() + ";" + a.getCategoria());
                    w2.newLine();
                }
            }
        }
    }

    /**
     * Carga la pila de departamentos (en orden) y sus colas.
     */
    public static void loadAll(PilaDepartamentos pila) throws IOException {
        Path dirPath = Paths.get(DIR);
        if (!Files.exists(dirPath)) return;  // nada que cargar

        Path deptsPath = dirPath.resolve(DEPTS_FILE);
        if (!Files.exists(deptsPath)) return;

        // 1) Leer departamentos
        try (BufferedReader reader = Files.newBufferedReader(deptsPath)) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(";", 2);
                int id = Integer.parseInt(parts[0]);
                String nombre = parts[1];
                pila.push(new Departamento(id, nombre));
            }
        }

        // 2) Leer cada archivo de artículos correspondiente
        for (Departamento d : pila.toArray()) {
            Path artPath = dirPath.resolve("articulos_" + d.getId() + ".txt");
            if (!Files.exists(artPath)) continue;
            try (BufferedReader r2 = Files.newBufferedReader(artPath)) {
                String ln;
                while ((ln = r2.readLine()) != null) {
                    String[] p = ln.split(";", 3);
                    int idArt = Integer.parseInt(p[0]);
                    String nomArt = p[1];
                    String cat = p[2];
                    d.encolarArticulo(new Articulo(idArt, nomArt, cat));
                }
            }
        }
    }
}