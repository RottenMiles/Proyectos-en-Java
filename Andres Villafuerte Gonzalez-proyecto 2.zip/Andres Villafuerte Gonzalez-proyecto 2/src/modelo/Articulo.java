package modelo;

/**
 * Representa un artículo con ID, nombre y categoría.
 */
public class Articulo {
    private final int id;           // Identificador único
    private final String nombre;    // Nombre descriptivo
    private final String categoria; // Categoría del artículo

    /**
     * Constructor.
     *
     * id        Identificador del artículo
     * nombre    Nombre del artículo
     * categoria Categoría asignada
     */
    public Articulo(int id, String nombre, String categoria) {
        this.id = id;
        this.nombre = nombre;
        this.categoria = categoria;
    }

    /**
     * @return El ID del artículo
     */
    public int getId() {
        return id;
    }

    /**
     * @return El nombre del artículo
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @return La categoría del artículo
     */
    public String getCategoria() {
        return categoria;
    }

    @Override
    public String toString() {
        return nombre; // para mostrar en JComboBox si lo necesitas
    }
}

