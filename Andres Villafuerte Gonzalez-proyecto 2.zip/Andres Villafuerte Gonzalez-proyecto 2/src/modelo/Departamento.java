package modelo;

/**
 * Representa un Departamento con una cola circular de Artículos.
 */
public class Departamento {
    private int id;
    private String nombre;
    private Articulo[] colaArticulos;
    private int frente, fin;

    public Departamento(int id, String nombre) {
        this.id = id;
        this.nombre = nombre;
        this.colaArticulos = new Articulo[20];
        this.frente = 0;
        this.fin = 0;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public boolean encolarArticulo(Articulo articulo) {
        int siguiente = (fin + 1) % colaArticulos.length;
        if (siguiente != frente) {
            colaArticulos[fin] = articulo;
            fin = siguiente;
            return true;
        }
        return false;
    }

    public Articulo desencolarArticulo() {
        if (frente == fin) return null;
        Articulo a = colaArticulos[frente];
        colaArticulos[frente] = null;
        frente = (frente + 1) % colaArticulos.length;
        return a;
    }

    public Articulo[] getArticulosEnCola() {
        int tamaño = (fin - frente + colaArticulos.length) % colaArticulos.length;
        Articulo[] res = new Articulo[tamaño];
        int idx = frente;
        for (int i = 0; i < tamaño; i++) {
            res[i] = colaArticulos[idx];
            idx = (idx + 1) % colaArticulos.length;
        }
        return res;
    }

    @Override
    public String toString() {
        // Esto hace que JComboBox muestre el nombre
        return nombre;
    }

    public boolean estaVacia() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}


