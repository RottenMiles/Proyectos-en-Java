package estructura;

import modelo.Departamento;

/**
 * Implementa una pila de Departamentos usando un arreglo de tamaño fijo.
 * Permite operaciones básicas: push, pop, peek, size y conversión a array.
 */
public class PilaDepartamentos {
    private final Departamento[] pila;  // Almacena los elementos de la pila
    private int tope;             // Índice del siguiente hueco (número de elementos)

    /**
     * Crea una pila con la capacidad indicada.
     *
     * @param capacidad Número máximo de Departamentos que puede contener.
     */
    public PilaDepartamentos(int capacidad) {
        this.pila = new Departamento[capacidad];
        this.tope = 0;
    }

    /**
     * Inserta un Departamento en el tope de la pila.
     *
     * @param depto El Departamento a apilar.
     * @return true si la operación tuvo éxito; false si la pila está llena.
     */
    public boolean push(Departamento depto) {
        if (tope < pila.length) {
            pila[tope++] = depto;
            return true;
        }
        return false;  // No hay espacio disponible
    }

    /**
     * Extrae y devuelve el Departamento que está en el tope.
     *
     * @return El Departamento extraído, o null si la pila está vacía.
     */
    public Departamento pop() {
        if (tope > 0) {
            return pila[--tope];
        }
        return null;  // Pila vacía
    }

    /**
     * Consulta cuál es el Departamento en el tope sin extraerlo.
     *
     * @return El Departamento en el tope, o null si la pila está vacía.
     */
    public Departamento peek() {
        return tope > 0 ? pila[tope - 1] : null;
    }

    /**
     * @return El número de Departamentos actualmente en la pila.
     */
    public int size() {
        return tope;
    }

    /**
     * Convierte el contenido de la pila a un array,
     * ordenado del fondo (índice 0) al tope (índice size-1).
     *
     * @return Un array con los Departamentos apilados, o un array vacío si la pila está vacía.
     */
    public Departamento[] toArray() {
        Departamento[] resultado = new Departamento[tope];
        System.arraycopy(pila, 0, resultado, 0, tope);
        return resultado;
    }
}
