package ui;

import estructura.PilaDepartamentos;
import modelo.Departamento;
import modelo.Articulo;
import ui.model.ColaArticulosTableModel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

/**
 * Ventana para trasladar artículos de un departamento origen a uno destino.
 * Permite seleccionar ambos departamentos, visualizar sus colas y transferir todos
 * los artículos del origen al destino.
 */
public class VentanaTransferenciaArticulos extends JFrame {
    /** Combo para seleccionar el departamento origen */
    private JComboBox<Departamento> cmbOrigen;
    /** Combo para seleccionar el departamento destino */
    private JComboBox<Departamento> cmbDestino;
    /** Botón para iniciar el traslado de artículos */
    private JButton btnTransferir;
    /** Tabla que muestra la cola de artículos del departamento origen */
    private JTable tblOrigen;
    /** Tabla que muestra la cola de artículos del departamento destino */
    private JTable tblDestino;
    /** Modelo de tabla para la cola de origen */
    private ColaArticulosTableModel modelOrigen;
    /** Modelo de tabla para la cola de destino */
    private ColaArticulosTableModel modelDestino;
    /** Pila de departamentos compartida */
    private final PilaDepartamentos pila;

    /**
     * Constructor de la ventana.
     * @param pila Pila de departamentos ya inicializada.
     */
    public VentanaTransferenciaArticulos(PilaDepartamentos pila) {
        super("Transferencia de Artículos");
        this.pila = pila;
        initComponents();
    }

    /**
     * Configura y organiza los componentes Swing.
     */
    private void initComponents() {
        // Inicializar combos con departamentos
        Departamento[] deps = pila.toArray();
        cmbOrigen = new JComboBox<>(deps);
        cmbDestino = new JComboBox<>(deps);
        cmbOrigen.setSelectedIndex(-1);
        cmbDestino.setSelectedIndex(-1);

        // Modelos y tablas para mostrar colas
        modelOrigen = new ColaArticulosTableModel(null);
        modelDestino = new ColaArticulosTableModel(null);
        tblOrigen = new JTable(modelOrigen);
        tblDestino = new JTable(modelDestino);

        // Botón de transferencia
        btnTransferir = new JButton("Transferir Todos");
        btnTransferir.addActionListener(this::onTransferir);

        // Listeners para actualizar tablas al cambiar selección
        cmbOrigen.addActionListener(e -> {
            Departamento origen = (Departamento) cmbOrigen.getSelectedItem();
            modelOrigen.setDepartamento(origen);
        });
        cmbDestino.addActionListener(e -> {
            Departamento destino = (Departamento) cmbDestino.getSelectedItem();
            modelDestino.setDepartamento(destino);
        });

        // Panel superior para combos y botón
        JPanel pnlTop = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        pnlTop.add(new JLabel("Origen:"));
        pnlTop.add(cmbOrigen);
        pnlTop.add(new JLabel("Destino:"));
        pnlTop.add(cmbDestino);
        pnlTop.add(btnTransferir);

        // Panel central con tablas lado a lado
        JPanel pnlCenter = new JPanel(new GridLayout(1, 2, 10, 10));
        pnlCenter.add(new JScrollPane(tblOrigen));
        pnlCenter.add(new JScrollPane(tblDestino));

        // Layout principal
        setLayout(new BorderLayout(10, 10));
        add(pnlTop, BorderLayout.NORTH);
        add(pnlCenter, BorderLayout.CENTER);

        // Ajustes finales
        pack();
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    }

    /**
     * Maneja el evento de transferencia de artículos.
     * Desencola todos los artículos del origen y los encola en destino.
     * @param e Evento de ActionEvent del botón.
     */
    private void onTransferir(ActionEvent e) {
        Departamento origen = (Departamento) cmbOrigen.getSelectedItem();
        Departamento destino = (Departamento) cmbDestino.getSelectedItem();
        if (origen == null || destino == null) {
            JOptionPane.showMessageDialog(this,
                "Seleccione ambos departamentos",
                "Error", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (origen == destino) {
            JOptionPane.showMessageDialog(this,
                "Origen y destino deben ser diferentes",
                "Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Transferir artículos hasta que la cola de origen quede vacía
        Articulo art;
        int count = 0;
        while ((art = origen.desencolarArticulo()) != null) {
            destino.encolarArticulo(art);
            count++;
        }

        // Mostrar resultado
        JOptionPane.showMessageDialog(this,
            count + " artículo(s) transferido(s)",
            "Transferencia completa", JOptionPane.INFORMATION_MESSAGE);

        // Refrescar ambas tablas
        modelOrigen.fireTableDataChanged();
        modelDestino.fireTableDataChanged();
    }

    /**
     * Método principal para lanzar la ventana de transferencia.
     * @param args Argumentos de línea de comando (sin usar).
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            // Crear pila y precargar algunos departamentos
            PilaDepartamentos pila = new PilaDepartamentos(50);
            pila.push(new Departamento(1, "Ventas"));
            pila.push(new Departamento(2, "Compras"));
            pila.push(new Departamento(3, "Inventario"));

            new VentanaTransferenciaArticulos(pila).setVisible(true);
        });
    }
}
