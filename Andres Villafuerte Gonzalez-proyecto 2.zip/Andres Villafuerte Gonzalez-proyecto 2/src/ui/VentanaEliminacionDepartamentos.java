package ui;

import estructura.PilaDepartamentos;
import modelo.Departamento;
import ui.model.PilaDepartamentosTableModel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

/**
 * Ventana para eliminar (pop) departamentos de la pila, solo si su cola de artículos está vacía.
 * Muestra la pila en una tabla y permite retirar el departamento del tope tras validar.
 */
public class VentanaEliminacionDepartamentos extends JFrame {
    /** Tabla que muestra la pila de departamentos */
    private JTable tabla;
    /** Modelo de tabla que refleja PilaDepartamentos */
    private PilaDepartamentosTableModel tableModel;
    /** Botón para eliminar el departamento del tope */
    private JButton btnEliminar;
    /** Pila de departamentos compartida */
    private PilaDepartamentos pila;

    /**
     * Constructor.
     * @param pila Pila de departamentos inicializada y compartida.
     */
    public VentanaEliminacionDepartamentos(PilaDepartamentos pila) {
        super("Eliminar Departamentos");
        this.pila = pila;
        initComponents();
    }

    /**
     * Inicializa componentes Swing y layout.
     */
    private void initComponents() {
        // Modelo y tabla de pila
        tableModel = new PilaDepartamentosTableModel(pila);
        tabla = new JTable(tableModel);

        // Botón de eliminación
        btnEliminar = new JButton("Eliminar Departamento");
        btnEliminar.addActionListener(this::onEliminar);

        // Panel superior con botón
        JPanel pnlTop = new JPanel(new FlowLayout(FlowLayout.LEFT));
        pnlTop.add(btnEliminar);

        // Layout principal
        setLayout(new BorderLayout(10, 10));
        add(pnlTop, BorderLayout.NORTH);
        add(new JScrollPane(tabla), BorderLayout.CENTER);

        // Ajustes de ventana
        pack();
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    }

    /**
     * Acción al pulsar "Eliminar Departamento".
     * Valida que la pila no esté vacía y que el tope tenga cola vacía.
     * Si pasa validación, hace pop y actualiza la tabla; si no, muestra error.
     * @param e Evento de click.
     */
    private void onEliminar(ActionEvent e) {
        Departamento tope = pila.peek();
        if (tope == null) {
            JOptionPane.showMessageDialog(this,
                "La pila está vacía",
                "Atención", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        // Verificar que el departamento no tenga artículos pendientes
        if (!tope.estaVacia()) {
            JOptionPane.showMessageDialog(this,
                "No se puede eliminar. El departamento tiene artículos en cola.",
                "Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Eliminar departamento del tope
        pila.pop();
        tableModel.fireTableDataChanged();
        JOptionPane.showMessageDialog(this,
            "Departamento eliminado exitosamente.",
            "Operación completa", JOptionPane.INFORMATION_MESSAGE);
    }

    /**
     * Punto de entrada para mostrar la ventana de eliminación.
     * Precarga algunos departamentos para ejemplo.
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            // Ejemplo de pila precargada
            PilaDepartamentos pila = new PilaDepartamentos(50);
            pila.push(new Departamento(1, "Ventas"));
            pila.push(new Departamento(2, "Compras"));

            new VentanaEliminacionDepartamentos(pila).setVisible(true);
        });
    }
}
