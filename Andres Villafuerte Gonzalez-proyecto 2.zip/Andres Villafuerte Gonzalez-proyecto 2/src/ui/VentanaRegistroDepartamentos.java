package ui;

import estructura.PilaDepartamentos;
import modelo.Departamento;
import ui.model.PilaDepartamentosTableModel;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.regex.Pattern;

/**
 * Ventana de registro de Departamentos con UI mejorada y asignación
 * de IDs única basada en los departamentos ya existentes.
 */
public class VentanaRegistroDepartamentos extends JFrame {
    private final PilaDepartamentos pila;
    private final PilaDepartamentosTableModel tableModel;
    private final TableRowSorter<PilaDepartamentosTableModel> sorter;

    private JTextField txtNombre, txtBuscar;
    private JLabel     lblError;
    private JButton    btnAgregar, btnEliminar;

    private int siguienteId;  // Ahora se calcula dinámicamente

    /**
     * Constructor.
     * @param pila La pila compartida de Departamentos.
     */
    public VentanaRegistroDepartamentos(PilaDepartamentos pila) {
        super("Registro de Departamentos");
        this.pila = pila;
        this.tableModel = new PilaDepartamentosTableModel(pila);
        this.sorter     = new TableRowSorter<>(tableModel);

        // —— Calcular el next ID según los departamentos ya cargados ——
        int maxId = 0;
        for (Departamento d : pila.toArray()) {
            if (d.getId() > maxId) {
                maxId = d.getId();
            }
        }
        siguienteId = maxId + 1;

        initComponents();
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(800, 500);
        setLocationRelativeTo(null);
    }

    /**
     * Inicializa y organiza todos los componentes de la interfaz.
     */
    private void initComponents() {
        // === PANEL DE FORMULARIO (IZQUIERDA) ===
        JPanel formPanel = new JPanel();
        formPanel.setBorder(new TitledBorder("Nuevo Departamento"));
        formPanel.setLayout(new BoxLayout(formPanel, BoxLayout.Y_AXIS));
        formPanel.setBorder(BorderFactory.createCompoundBorder(
            formPanel.getBorder(),
            new EmptyBorder(10,10,10,10)
        ));

        // Campo de texto para nombre
        txtNombre = new JTextField();
        txtNombre.setMaximumSize(new Dimension(Integer.MAX_VALUE, 28));
        txtNombre.getDocument().addDocumentListener(new DocumentListener() {
            private void validar() {
                String t = txtNombre.getText().trim();
                boolean ok = !t.isEmpty() && t.length() <= 15;
                lblError.setText(t.isEmpty()
                    ? "– El nombre es obligatorio"
                    : t.length() > 15
                        ? "– Máximo 15 caracteres"
                        : " ");
                btnAgregar.setEnabled(ok);
            }
            @Override public void insertUpdate(DocumentEvent e) { validar(); }
            @Override public void removeUpdate(DocumentEvent e) { validar(); }
            @Override public void changedUpdate(DocumentEvent e){ validar(); }
        });

        lblError = new JLabel(" ");
        lblError.setForeground(Color.RED);

        // Toolbar con acciones
        JToolBar toolBar = new JToolBar();
        toolBar.setFloatable(false);
        btnAgregar = new JButton("Agregar");
        btnAgregar.setToolTipText("Agregar nuevo departamento");
        btnAgregar.setEnabled(false);
        btnAgregar.addActionListener(this::onAgregar);
        btnEliminar = new JButton("Eliminar tope");
        btnEliminar.setToolTipText("Eliminar el departamento del tope");
        btnEliminar.addActionListener(this::onEliminar);
        toolBar.add(btnAgregar);
        toolBar.addSeparator();
        toolBar.add(btnEliminar);

        formPanel.add(new JLabel("Nombre:"));
        formPanel.add(Box.createVerticalStrut(4));
        formPanel.add(txtNombre);
        formPanel.add(Box.createVerticalStrut(2));
        formPanel.add(lblError);
        formPanel.add(Box.createVerticalStrut(10));
        formPanel.add(toolBar);
        formPanel.add(Box.createVerticalGlue());

        // === PANEL DE TABLA (DERECHA) ===
        JPanel tablePanel = new JPanel(new BorderLayout(5,5));
        tablePanel.setBorder(new TitledBorder("Departamentos Existentes"));

        // Filtro de búsqueda
        JPanel searchPanel = new JPanel(new BorderLayout(4,4));
        txtBuscar = new JTextField();
        txtBuscar.setToolTipText("Filtrar por nombre de departamento");
        txtBuscar.getDocument().addDocumentListener(new DocumentListener() {
            private void filtrar() {
                String text = txtBuscar.getText().trim();
                if (text.isEmpty()) {
                    sorter.setRowFilter(null);
                } else {
                    sorter.setRowFilter(RowFilter.regexFilter(
                        "(?i)" + Pattern.quote(text), 1));
                }
            }
            @Override public void insertUpdate(DocumentEvent e) { filtrar(); }
            @Override public void removeUpdate(DocumentEvent e) { filtrar(); }
            @Override public void changedUpdate(DocumentEvent e){ filtrar(); }
        });
        searchPanel.add(new JLabel("Buscar:"), BorderLayout.WEST);
        searchPanel.add(txtBuscar, BorderLayout.CENTER);

        JTable tabla = new JTable(tableModel);
        tabla.setRowSorter(sorter);

        tablePanel.add(searchPanel, BorderLayout.NORTH);
        tablePanel.add(new JScrollPane(tabla), BorderLayout.CENTER);

        // === SPLIT PANE PARA FORMULARIO Y TABLA ===
        JSplitPane split = new JSplitPane(
            JSplitPane.HORIZONTAL_SPLIT,
            formPanel,
            tablePanel
        );
        split.setResizeWeight(0.3);
        split.setOneTouchExpandable(true);

        getContentPane().add(split, BorderLayout.CENTER);
    }

    /**
     * Evento al pulsar "Agregar": crea y apila un nuevo Departamento.
     */
    private void onAgregar(ActionEvent e) {
        String nombre = txtNombre.getText().trim();
        Departamento d = new Departamento(siguienteId++, nombre);
        if (!pila.push(d)) {
            JOptionPane.showMessageDialog(this,
                "La pila está llena",
                "Error",
                JOptionPane.ERROR_MESSAGE);
            return;
        }
         // Actualiza la tabla
        tableModel.fireTableDataChanged();
         // Limpia el campo de texto
        txtNombre.setText("");
        // **Limpia también el mensaje de error y deshabilita el botón**
        lblError.setText(" ");
        btnAgregar.setEnabled(false);
    }
  
   
    /**
     * Evento al pulsar "Eliminar tope": desencola del tope si existe.
     */
    private void onEliminar(ActionEvent e) {
        if (pila.pop() == null) {
            JOptionPane.showMessageDialog(this,
                "La pila está vacía",
                "Atención",
                JOptionPane.INFORMATION_MESSAGE);
        } else {
            tableModel.fireTableDataChanged();
        }
    }
}
