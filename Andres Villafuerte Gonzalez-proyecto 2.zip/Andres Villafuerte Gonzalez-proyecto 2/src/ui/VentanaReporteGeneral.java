package ui;

import estructura.PilaDepartamentos;
import modelo.Departamento;
import modelo.Articulo;

import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import java.awt.*;
import java.awt.event.ActionEvent;

/**
 * Ventana de reporte general que muestra todos los Departamentos y,
 * bajo cada uno, sus Artículos en una vista de árbol.
 */
public class VentanaReporteGeneral extends JFrame {
    private final PilaDepartamentos pila;      // Pila de departamentos compartida
    private JTree treeReporte;                 // Componente de árbol para el reporte
    private DefaultTreeModel treeModel;        // Modelo del árbol
    private JButton btnRefrescar;              // Botón para recargar datos

    /**
     * Constructor.
     * @param pila La pila de Departamentos con sus colas de Artículos.
     */
    public VentanaReporteGeneral(PilaDepartamentos pila) {
        super("Reporte General");
        this.pila = pila;
        initComponents();
        pack();
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    }

    /**
     * Inicializa la UI: crea el árbol, el botón y el layout.
     */
    private void initComponents() {
        // Raíz del árbol
        DefaultMutableTreeNode root = new DefaultMutableTreeNode("Departamentos");
        treeModel = new DefaultTreeModel(root);
        treeReporte = new JTree(treeModel);

        // Construye inicialmente el contenido del árbol
        construirArbol();

        // Botón para recargar el reporte
        btnRefrescar = new JButton("Refrescar");
        btnRefrescar.addActionListener(this::onRefrescar);

        // Layout: árbol en el centro, botón abajo
        setLayout(new BorderLayout(8, 8));
        add(new JScrollPane(treeReporte), BorderLayout.CENTER);

        JPanel pnlSur = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        pnlSur.add(btnRefrescar);
        add(pnlSur, BorderLayout.SOUTH);
    }

    /**
     * Reconstruye el modelo del árbol usando el estado actual de la pila.
     */
    private void construirArbol() {
        // Nodo raíz
        DefaultMutableTreeNode root = (DefaultMutableTreeNode) treeModel.getRoot();
        root.removeAllChildren();

        // Para cada departamento en la pila (fondo → tope)
        for (Departamento depto : pila.toArray()) {
            // Crea un nodo para el departamento con su nombre e ID
            String nodoDepto = String.format("[%d] %s", depto.getId(), depto.getNombre());
            DefaultMutableTreeNode nodoRaizDepto = new DefaultMutableTreeNode(nodoDepto);

            // Añade un hijo por cada artículo en su cola
            for (Articulo art : depto.getArticulosEnCola()) {
                String nodoArt = String.format("(%d) %s - %s",
                        art.getId(), art.getNombre(), art.getCategoria());
                nodoRaizDepto.add(new DefaultMutableTreeNode(nodoArt));
            }

            root.add(nodoRaizDepto);
        }

        // Notifica al modelo que cambió la estructura
        treeModel.reload(root);
        // Expande los primeros niveles
        treeReporte.expandRow(0);
    }

    /**
     * Evento al pulsar el botón “Refrescar”: reconstruye el árbol.
     */
    private void onRefrescar(ActionEvent e) {
        construirArbol();
    }

    /**
     * Método de prueba standalone.
     * Crea una pila de ejemplo y abre la ventana.
     */
    public static void main(String[] args) {
        // Ejemplo de uso
        PilaDepartamentos pilaDemo = new PilaDepartamentos(10);
        Departamento d1 = new Departamento(1, "Ventas");
        d1.encolarArticulo(new Articulo(1, "Laptop", "Cat1"));
        d1.encolarArticulo(new Articulo(2, "Mouse",  "Cat2"));
        Departamento d2 = new Departamento(2, "Compras");
        d2.encolarArticulo(new Articulo(1, "Papel",  "Cat3"));
        pilaDemo.push(d1);
        pilaDemo.push(d2);

        SwingUtilities.invokeLater(() -> {
            new VentanaReporteGeneral(pilaDemo).setVisible(true);
        });
    }
}
