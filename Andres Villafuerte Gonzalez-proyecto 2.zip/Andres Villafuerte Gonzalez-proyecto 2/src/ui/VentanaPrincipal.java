//                                                Universidad Estatal a Distancia

//                                            Escuela de Ciencias Exactas y Naturales

//                                               Cátedra de Ingeniería de Software

//                                                           PROYECTO: #02

//                                                      Estructuras de Datos

//                                                         Código: 000824

//                                                 Centro Universitario: San José

//                                                  Andrés Villafuerte González

//                                                      Cédula:1-1835-0456

//                                                           Grupo:01

//                                                      Fecha: 11/07/2025
//-------------------------------------------------------------------------------------------------------------------------------------------
package ui;

import Persistencia.DataManager;
import estructura.PilaDepartamentos;


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;

/**
 * Ventana principal de la aplicación.
 * <p>
 * - Carga al iniciar la pila de Departamentos y sus Artículos desde archivos.
 * - Muestra un menú y botones para navegar a cada módulo:
 *   • Registrar Departamentos  
 *   • Registrar Artículos  
 *   • Transferir Artículos  
 *   • Eliminar Departamentos  
 *   • Reporte General  
 * - Al cerrar, guarda automáticamente el estado actual en disco.
 * </p>
 */
public class VentanaPrincipal extends JFrame implements ActionListener {

    private final PilaDepartamentos pila;   // Pila compartida entre módulos

    // —— Componentes de menú ——  
    private JMenuItem miRegistroDept;
    private JMenuItem miRegistroArt;
    private JMenuItem miTransferirArt;
    private JMenuItem miEliminarDept;
    private JMenuItem miReporteGeneral;

    // —— Botones de acceso directo ——  
    private JButton btnRegistroDept;
    private JButton btnRegistroArt;
    private JButton btnTransferirArt;
    private JButton btnEliminarDept;
    private JButton btnReporteGeneral;

    /**
     * Construye la ventana principal: carga datos, inicializa UI y configura guardado al cerrar.
     */
    public VentanaPrincipal() {
        super("Gestión de Departamentos y Artículos");

        // 1) Inicializar la pila y cargar persistencia
        pila = new PilaDepartamentos(50);
        try {
            DataManager.loadAll(pila);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(
                this,
                "Error al cargar datos iniciales:\n" + ex.getMessage(),
                "Carga de Datos",
                JOptionPane.ERROR_MESSAGE
            );
        }

        // 2) Configurar interfaz de usuario
        initComponents();

        // 3) Ajustes de ventana
        setSize(700, 450);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);

        // 4) Guardar al cerrar
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                persistirDatos();
                dispose();
            }
        });
    }

    /**
     * Inicializa menús, botones y layouts.
     */
    private void initComponents() {
        // —— MENÚ ——  
        JMenuBar menuBar = new JMenuBar();
        JMenu menuOps = new JMenu("Operaciones");

        miRegistroDept   = new JMenuItem("Registrar Departamentos");
        miRegistroArt    = new JMenuItem("Registrar Artículos");
        miTransferirArt  = new JMenuItem("Transferir Artículos");
        miEliminarDept   = new JMenuItem("Eliminar Departamentos");
        miReporteGeneral = new JMenuItem("Reporte General");

        // Asociar listener
        miRegistroDept.addActionListener(this);
        miRegistroArt .addActionListener(this);
        miTransferirArt.addActionListener(this);
        miEliminarDept .addActionListener(this);
        miReporteGeneral.addActionListener(this);

        // Montar menú
        menuOps.add(miRegistroDept);
        menuOps.add(miRegistroArt);
        menuOps.add(miTransferirArt);
        menuOps.add(miEliminarDept);
        menuOps.addSeparator();
        menuOps.add(miReporteGeneral);
        menuBar.add(menuOps);
        setJMenuBar(menuBar);

        // —— PANEL CENTRAL CON BOTONES ——  
        // Usamos un GridLayout dinámico de 3 columnas
        JPanel pnlMain = new JPanel(new GridLayout(0, 3, 15, 15));

        btnRegistroDept   = new JButton("📥 Registrar Departamentos");
        btnRegistroArt    = new JButton("📝 Registrar Artículos");
        btnTransferirArt  = new JButton("🔄 Transferir Artículos");
        btnEliminarDept   = new JButton("❌ Eliminar Departamentos");
        btnReporteGeneral = new JButton("📊 Reporte General");

        // Asociar mismo listener
        btnRegistroDept  .addActionListener(this);
        btnRegistroArt   .addActionListener(this);
        btnTransferirArt .addActionListener(this);
        btnEliminarDept  .addActionListener(this);
        btnReporteGeneral.addActionListener(this);

        // Añadir botones (el último hueco queda vacío si es impar)
        pnlMain.add(btnRegistroDept);
        pnlMain.add(btnRegistroArt);
        pnlMain.add(btnTransferirArt);
        pnlMain.add(btnEliminarDept);
        pnlMain.add(btnReporteGeneral);

        // Layout principal
        getContentPane().setLayout(new BorderLayout(20, 20));
        getContentPane().add(pnlMain, BorderLayout.CENTER);
    }

    /**
     * Maneja eventos de menú y botones, abre la ventana correspondiente.
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        Object src = e.getSource();
        try {
            if (src == miRegistroDept || src == btnRegistroDept) {
                abrirRegistroDepartamentos();
            } else if (src == miRegistroArt || src == btnRegistroArt) {
                abrirRegistroArticulos();
            } else if (src == miTransferirArt || src == btnTransferirArt) {
                abrirTransferenciaArticulos();
            } else if (src == miEliminarDept || src == btnEliminarDept) {
                abrirEliminacionDepartamentos();
            } else if (src == miReporteGeneral || src == btnReporteGeneral) {
                abrirReporteGeneral();
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(
                this,
                "Error al abrir la ventana:\n" + ex.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }

    /** Abre la ventana de registro de departamentos. */
    private void abrirRegistroDepartamentos() {
        new VentanaRegistroDepartamentos(pila).setVisible(true);
    }

    /** Abre la ventana de registro de artículos. */
    private void abrirRegistroArticulos() {
        new VentanaRegistroArticulos(pila).setVisible(true);
    }

    /** Abre la ventana de transferencia de artículos. */
    private void abrirTransferenciaArticulos() {
        new VentanaTransferenciaArticulos(pila).setVisible(true);
    }

    /** Abre la ventana de eliminación de departamentos. */
    private void abrirEliminacionDepartamentos() {
        new VentanaEliminacionDepartamentos(pila).setVisible(true);
    }

    /** Abre la ventana de reporte general. */
    private void abrirReporteGeneral() {
        new VentanaReporteGeneral(pila).setVisible(true);
    }

    /** Guarda en disco la pila de departamentos y sus artículos. */
    private void persistirDatos() {
        try {
            DataManager.saveAll(pila);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(
                this,
                "Error al guardar datos:\n" + ex.getMessage(),
                "Guardado de Datos",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }

    /** Método principal para lanzar la aplicación. */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new VentanaPrincipal().setVisible(true));
    }
}

//Fuentes: 

/**The Java™ Tutorials: Creating a GUI With Swing
Guía paso a paso para construir interfaces con Swing, incluyendo componentes, contenedores y gestión de eventos.
https://docs.oracle.com/javase/tutorial/uiswing/overview/index.html

The Java™ Tutorials: How to Use Tables
Explica cómo usar JTable y modelos de tabla (AbstractTableModel), así como filtros con TableRowSorter.
https://docs.oracle.com/javase/tutorial/uiswing/components/table.html

The Java™ Tutorials: How to Use Trees
Cobertura de JTree, DefaultTreeModel y nodos (DefaultMutableTreeNode) para vistas en árbol.
https://docs.oracle.com/javase/tutorial/uiswing/components/tree.html

The Java™ Tutorials: Essential Java Classes – I/O
Introducción al manejo de archivos con las clases de NIO (Files, Paths, BufferedReader/Writer).
https://docs.oracle.com/javase/tutorial/essential/io/

Java SE API Specification
Referencia completa de las clases usadas (java.util, javax.swing, java.nio.file, etc.).
https://docs.oracle.com/en/java/javase/11/docs/api/index.html

Unidad Didactica:
Estructura de datos: un enfoque con Python, Java y C++ / Enrique Gómez Jiménez y Perci Cañipa Valdez --
Primera edición -- Bogotá: Alpha Editorial, 2023. 

Horstmann, Cay S.; Cornell, Gary. Core Java Volume I—Fundamentals, 11th ed. Prentice Hall, 2018.
 
Stack Overflow. java 8 – circular buffer. Ideas para manejar la cola circular en Departamento . 
https://stackoverflow.com/questions/54185559/java-8-circular-buffer 

Stack Overflow. Smarter way to use Java DocumentListener. Ejemplos de validación en campos de texto. 
https://stackoverflow.com/questions/26264880/smarter-way-to-use-java-documentlistener 

Baeldung. Introduction to Java NIO2 File API. Tutorial en Baeldung. Ejemplos sencillos de lectura y escritura de archivos con Files. 
 https://www.baeldung.com/java-nio-2-file-api
  */