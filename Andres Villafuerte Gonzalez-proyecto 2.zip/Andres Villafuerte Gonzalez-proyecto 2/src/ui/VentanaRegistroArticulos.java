package ui;

import estructura.PilaDepartamentos;
import modelo.Articulo;
import modelo.Departamento;
import ui.model.ColaArticulosTableModel;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * Ventana para encolar y desencolar Artículos,
 * con JComboBox mostrando correctamente el nombre de cada Departamento.
 */
public class VentanaRegistroArticulos extends JFrame {
    private final PilaDepartamentos pila;
    private ColaArticulosTableModel articuloModel;
    private TableRowSorter<ColaArticulosTableModel> sorterArt;

    private JComboBox<Departamento> cmbDepartamentos;
    private JTextField txtNombreArticulo;
    private JLabel lblErrorArticulo;
    private JComboBox<String> cmbCategoria, cmbFiltroCategoria;
    private JTextField txtBuscarArticulo;
    private JButton btnAgregar, btnDesencolar;
    private JTable tablaArticulos;

    public VentanaRegistroArticulos(PilaDepartamentos pila) {
        super("Registro de Artículos");
        this.pila = pila;
        initComponents();
    }

    private void initComponents() {
        // ComboBox de Departamentos, usa toString() para mostrar nombre
        cmbDepartamentos = new JComboBox<>(pila.toArray());
        cmbDepartamentos.setSelectedIndex(-1);

        // Campo y validación de nombre de artículo
        txtNombreArticulo = new JTextField(15);
        lblErrorArticulo  = new JLabel(" ");
        lblErrorArticulo.setForeground(Color.RED);
        txtNombreArticulo.getDocument().addDocumentListener(new DocumentListener() {
            private void validar() {
                String t = txtNombreArticulo.getText().trim();
                boolean ok = true;
                if (t.isEmpty()) {
                    lblErrorArticulo.setText("Nombre requerido");
                    ok = false;
                } else if (t.length() > 20) {
                    lblErrorArticulo.setText("Máximo 20 caracteres");
                    ok = false;
                } else {
                    lblErrorArticulo.setText(" ");
                }
                btnAgregar.setEnabled(ok && cmbDepartamentos.getSelectedItem() != null);
            }
            @Override public void insertUpdate(DocumentEvent e) { validar(); }
            @Override public void removeUpdate(DocumentEvent e) { validar(); }
            @Override public void changedUpdate(DocumentEvent e){ validar(); }
        });

        // Categorías y filtro de categoría
        String[] cats = { "Todas", "Cat1","Cat2","Cat3","Cat4","Cat5","Cat6","Cat7" };
        cmbCategoria       = new JComboBox<>(cats);
        cmbFiltroCategoria = new JComboBox<>(cats);

        // Botones
        btnAgregar   = new JButton("Agregar Artículo");
        btnDesencolar= new JButton("Desencolar Artículo");
        btnAgregar.setEnabled(false);
        btnDesencolar.setEnabled(false);

        // Tabla y sorter
        articuloModel  = new ColaArticulosTableModel(null);
        tablaArticulos = new JTable(articuloModel);
        sorterArt      = new TableRowSorter<>(articuloModel);
        tablaArticulos.setRowSorter(sorterArt);

        // Filtro de nombre de artículo
        txtBuscarArticulo = new JTextField(12);
        txtBuscarArticulo.getDocument().addDocumentListener(new DocumentListener() {
            private void filtrar() { aplicaFiltros(); }
            @Override public void insertUpdate(DocumentEvent e) { filtrar(); }
            @Override public void removeUpdate(DocumentEvent e) { filtrar(); }
            @Override public void changedUpdate(DocumentEvent e){ filtrar(); }
        });

        // Al cambiar departamento, actualizar tabla y habilitar botones
        cmbDepartamentos.addActionListener(e -> {
            Departamento sel = (Departamento) cmbDepartamentos.getSelectedItem();
            articuloModel.setDepartamento(sel);
            btnDesencolar.setEnabled(sel != null && sel.getArticulosEnCola().length > 0);
        });

        btnAgregar.addActionListener(this::onAgregar);
        btnDesencolar.addActionListener(this::onDesencolar);

        // Layout de formulario y filtros
        JPanel pnlTop = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(4,4,4,4);
        c.gridx=0; c.gridy=0; pnlTop.add(new JLabel("Departamento:"), c);
        c.gridx=1;            pnlTop.add(cmbDepartamentos, c);

        c.gridx=0; c.gridy=1; pnlTop.add(new JLabel("Nombre Artículo:"), c);
        c.gridx=1;            pnlTop.add(txtNombreArticulo, c);
        c.gridx=1; c.gridy=2; pnlTop.add(lblErrorArticulo, c);

        c.gridx=0; c.gridy=3; pnlTop.add(new JLabel("Categoría:"), c);
        c.gridx=1;            pnlTop.add(cmbCategoria, c);

        c.gridx=0; c.gridy=4; pnlTop.add(btnAgregar, c);
        c.gridx=1;            pnlTop.add(btnDesencolar, c);

        JPanel pnlFiltros = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));
        pnlFiltros.add(new JLabel("Buscar:"));
        pnlFiltros.add(txtBuscarArticulo);
        pnlFiltros.add(new JLabel("Filtrar categoría:"));
        pnlFiltros.add(cmbFiltroCategoria);

        JPanel pnlCenter = new JPanel(new BorderLayout(5,5));
        pnlCenter.add(pnlFiltros, BorderLayout.NORTH);
        pnlCenter.add(new JScrollPane(tablaArticulos), BorderLayout.CENTER);

        setLayout(new BorderLayout(10,10));
        add(pnlTop,    BorderLayout.NORTH);
        add(pnlCenter, BorderLayout.CENTER);

        setSize(700, 450);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    }

    private void aplicaFiltros() {
        String text = txtBuscarArticulo.getText().trim();
        String cat  = (String) cmbFiltroCategoria.getSelectedItem();
        List<RowFilter<Object,Object>> filtros = new ArrayList<>();
        if (!text.isEmpty()) {
            filtros.add(RowFilter.regexFilter("(?i)" + Pattern.quote(text), 1));
        }
        if (cat != null && !"Todas".equals(cat)) {
            filtros.add(RowFilter.regexFilter("^" + Pattern.quote(cat) + "$", 2));
        }
        RowFilter<Object,Object> rf = filtros.isEmpty() ? null : RowFilter.andFilter(filtros);
        sorterArt.setRowFilter(rf);
    }

    private void onAgregar(ActionEvent e) {
        Departamento depto = (Departamento) cmbDepartamentos.getSelectedItem();
        Articulo art = new Articulo(
            depto.getArticulosEnCola().length + 1,
            txtNombreArticulo.getText().trim(),
            (String)cmbCategoria.getSelectedItem()
        );
        if (!depto.encolarArticulo(art)) {
            JOptionPane.showMessageDialog(this,
                "Cola llena", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        articuloModel.fireTableDataChanged();
        txtNombreArticulo.setText("");
        aplicaFiltros();
    }

    private void onDesencolar(ActionEvent e) {
        Departamento depto = (Departamento) cmbDepartamentos.getSelectedItem();
        if (depto.desencolarArticulo() == null) {
            JOptionPane.showMessageDialog(this,
                "Cola vacía", "Atención", JOptionPane.INFORMATION_MESSAGE);
        } else {
            articuloModel.fireTableDataChanged();
            aplicaFiltros();
        }
    }
}
