package ui.model;

import estructura.PilaDepartamentos;
import modelo.Departamento;

import javax.swing.table.AbstractTableModel;

/**
 * TableModel para mostrar una PilaDepartamentos en un JTable.
 * Cada fila representa un Departamento, mostrado en orden LIFO.
 */
public class PilaDepartamentosTableModel extends AbstractTableModel {
    private final String[] columnas = { "ID", "Nombre" };
    private final PilaDepartamentos pila;

    /**
     * Constructor.
     * 
     * @param pila la estructura de datos que contiene los Departamentos
     */
    public PilaDepartamentosTableModel(PilaDepartamentos pila) {
        this.pila = pila;
    }

    @Override
    public int getRowCount() {
        // Número de elementos en la pila
        return pila.size();
    }

    @Override
    public int getColumnCount() {
        // Dos columnas: ID y Nombre
        return columnas.length;
    }

    @Override
    public String getColumnName(int col) {
        return columnas[col];
    }

    @Override
    public Object getValueAt(int row, int col) {
        // Convierte la pila a array (del fondo al tope) para indexar por fila
        Departamento[] deps = pila.toArray();
        Departamento d = deps[row];

        switch (col) {
            case 0:
                // Columna 0: ID del departamento
                return d.getId();
            case 1:
                // Columna 1: Nombre del departamento
                return d.getNombre();
            default:
                return null;
        }
    }
}
