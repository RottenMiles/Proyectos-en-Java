package ui.model;

import modelo.Articulo;
import modelo.Departamento;
import javax.swing.table.AbstractTableModel;

/**
 * TableModel para mostrar la cola de Artículos de un Departamento.
 */
public class ColaArticulosTableModel extends AbstractTableModel {
    private final String[] columnas = { "ID", "Nombre", "Categoría" };
    private Departamento departamento;

    /**
     * Constructor.
     * @param depto Departamento inicial (puede ser null).
     */
    public ColaArticulosTableModel(Departamento depto) {
        this.departamento = depto;
    }

    /**
     * Actualiza el Departamento cuyo contenido se mostrará
     * y notifica al JTable que sus datos cambiaron.
     */
    public void setDepartamento(Departamento depto) {
        this.departamento = depto;
        super.fireTableDataChanged();
    }

    @Override
    public int getRowCount() {
        return departamento == null ? 0 : departamento.getArticulosEnCola().length;
    }

    @Override
    public int getColumnCount() {
        return columnas.length;
    }

    @Override
    public String getColumnName(int col) {
        return columnas[col];
    }

    @Override
    public Object getValueAt(int row, int col) {
        Articulo[] lista = departamento == null
            ? new Articulo[0]
            : departamento.getArticulosEnCola();
        if (row < 0 || row >= lista.length) return null;
        Articulo a = lista[row];
        return switch (col) {
            case 0 -> a.getId();
            case 1 -> a.getNombre();
            case 2 -> a.getCategoria();
            default -> null;
        };
    }
}
